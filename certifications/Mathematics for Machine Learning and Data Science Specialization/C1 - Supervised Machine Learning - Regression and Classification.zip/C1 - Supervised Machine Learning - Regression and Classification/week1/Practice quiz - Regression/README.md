![](/C1%20-%20Supervised%20Machine%20Learning:%20Regression%20and%20Classification/week1/Practice%20quiz:%20Regression/ss1.png)
